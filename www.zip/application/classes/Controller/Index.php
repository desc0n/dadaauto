<?php defined('SYSPATH') or die('No direct script access.');

class Controller_Index extends Controller
{
    public function getBaseTemplate()
    {
        return View::factory("template")
            ->set('get', $_GET)
            ->set('post', $_POST);
    }

	public function action_index()
	{
        $template = $this->getBaseTemplate();

        $template->content = View::factory("index");
		$this->response->body($template);
	}

	public function action_about()
	{
        $template = $this->getBaseTemplate();

        $template->content = View::factory("about");
		$this->response->body($template);
	}

	public function action_zakaz()
	{
        $template = $this->getBaseTemplate();

        $template->content = View::factory("zakaz");
		$this->response->body($template);
	}

	public function action_pay()
	{
        $template = $this->getBaseTemplate();

        $template->content = View::factory("pay");
		$this->response->body($template);
	}
}